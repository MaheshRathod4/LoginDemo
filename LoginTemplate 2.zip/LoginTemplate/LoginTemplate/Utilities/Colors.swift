//
//  Color.swift
//  LoginTemplate
//
//  Created by pc on 16/07/20.
//  Copyright © 2020 pc. All rights reserved.
//

import Foundation
import UIKit

struct Colors {
    static let colorPrimary  =  UIColor(red: 0.231, green: 0.792, blue: 0.604, alpha: 1)
    
}


